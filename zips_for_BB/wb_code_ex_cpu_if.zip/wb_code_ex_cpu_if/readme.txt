create folder "HDL"
- put "hdl_doxyfile" here
create subfolder "src"
- put all VHDL+ucf files in a folder 
create subfolder "sim"
- put simulation files here