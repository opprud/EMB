/*
 * type.h
 *
 *  Created on: 27/08/2010
 *      Author: Administrator
 */

#ifndef TYPE_H_
#define TYPE_H_

#define TRUE	1
#define FALSE	0

#define OK		0
#define FAIL	-1


#endif /* TYPE_H_ */
