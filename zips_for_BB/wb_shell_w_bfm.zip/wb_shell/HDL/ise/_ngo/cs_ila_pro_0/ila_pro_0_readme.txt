The following files were generated for 'ila_pro_0' in directory 
C:\Workspace\EMB\WB_shell\HDL\ise\_ngo\cs_ila_pro_0\

ila_pro_0.cdc:
   Please see the core data sheet.

ila_pro_0.gise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

ila_pro_0.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

ila_pro_0.vhd:
   Unisim VHDL file containing the information required to simulate
   the module.

ila_pro_0.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

ila_pro_0.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

ila_pro_0.xise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

ila_pro_0_readme.txt:
   Text file indicating the files generated and how they are used.

ila_pro_0_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.

ila_pro_0_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

