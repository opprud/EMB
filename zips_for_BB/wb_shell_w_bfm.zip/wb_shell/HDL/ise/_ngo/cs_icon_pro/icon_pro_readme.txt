The following files were generated for 'icon_pro' in directory 
C:\Workspace\EMB\WB_shell\HDL\ise\_ngo\cs_icon_pro\

icon_pro.gise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

icon_pro.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

icon_pro.vhd:
   Unisim VHDL file containing the information required to simulate
   the module.

icon_pro.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

icon_pro.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

icon_pro.xise:
   ISE Project Navigator support file. This is a generated file and should
   not be edited directly.

icon_pro_readme.txt:
   Text file indicating the files generated and how they are used.

icon_pro_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.

icon_pro_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

