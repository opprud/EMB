/******************************************************************************
 *
 * Copyright:
 *    (C) 2000 - 2005 Embedded Artists AB
 *
 * Description:
 *    Framework for ARM7 processor
 *
 *****************************************************************************/


#ifndef _framework_h_
#define _framework_h_

#include "config.h"

void lowLevelInit(void);

#endif
