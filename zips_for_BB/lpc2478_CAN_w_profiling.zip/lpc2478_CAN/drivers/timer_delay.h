/*
 * timer.h
 *
 *  Created on: 09/09/2010
 *      Author: morten
 */

#ifndef TIMER_H_
#define TIMER_H_

void delayMs(int delayInMs);

#endif /* TIMER_H_ */
