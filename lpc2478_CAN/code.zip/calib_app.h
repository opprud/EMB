/*
 * calib_app.h
 *
 *  Created on: 12/10/2010
 *      Author: morten
 */

#ifndef CALIB_APP_H_
#define CALIB_APP_H_


void calibrateStart(void);
void lcd_test(void);
int open_lcd();

#endif /* CALIB_APP_H_ */
