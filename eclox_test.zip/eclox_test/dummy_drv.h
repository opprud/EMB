/**
 * dummy_drv.h
 *
 * @file
 *  Created on: 26/10/2010
 *      Author: morten
 */
#ifndef DUMMY_DRV_H_
#define DUMMY_DRV_H_


int dummy_init(int a, int b);

#endif /* DUMMY_DRV_H_ */
